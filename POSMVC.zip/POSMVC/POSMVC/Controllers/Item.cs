﻿using POSMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POSMVC.Controllers
{
    public class Item
    {
        private Product_Table pr = new Product_Table();

        public Product_Table Pr
        {
            get { return pr; }
            set { pr = value; }
        }
        private int quantity;
       

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        public Item()
        {

        }

        public Item(Product_Table pr, int quantity)
        {
            this.pr = pr;
            this.quantity = quantity;
        }

      
    }
}