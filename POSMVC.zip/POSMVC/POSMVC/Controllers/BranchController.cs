﻿using POSMVC.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace POSMVC.Controllers
{
    [Authorize(Roles = "Admin")]
    public class BranchController : Controller
    {
        private POSDBEntities2 db = new POSDBEntities2();
        // GET: Category
        public ActionResult Index()
        {
            return View(db.Branch_Table.ToList());
        }

        // GET: StockProduct/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Branch_Table branch_Table = db.Branch_Table.Find(id);
            if (branch_Table == null)
            {
                return HttpNotFound();
            }
            return View(branch_Table);
        }


        // GET: StockProduct/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StockProduct/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public ActionResult Create(Branch_Table branch_Table)
        {

            db.SaveBranchSP(branch_Table.Branch_Name);

            ViewBag.success = "Data save successfully";
            return RedirectToAction("index");
        }

        // GET: StockProduct/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Branch_Table branch_Table = db.Branch_Table.Find(id);
            if (branch_Table == null)
            {
                return HttpNotFound();
            }
            return View(branch_Table);
        }

        // POST: StockProduct/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Branch_Name")] Branch_Table branch_Table)
        {
            if (ModelState.IsValid)
            {
                db.Entry(branch_Table).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(branch_Table);
        }

        // GET: StockProduct/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Branch_Table branch_Table = db.Branch_Table.Find(id);
            if (branch_Table == null)
            {
                return HttpNotFound();
            }
            return View(branch_Table);
        }

        // POST: StockProduct/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Branch_Table branch_Table = db.Branch_Table.Find(id);
            db.Branch_Table.Remove(branch_Table);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}
