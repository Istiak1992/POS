﻿using POSMVC.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace POSMVC.Controllers
{
     [Authorize(Roles = "Admin")]
    public class StockProductController : Controller
    {
        private POSDBEntities2 db = new POSDBEntities2();
        // GET: StockProduct
        public ActionResult Index()
        {
            return View(db.Product_Table.ToList());
        }

        // GET: StockProduct/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product_Table product_Table = db.Product_Table.Find(id);
            if (product_Table == null)
            {
                return HttpNotFound();
            }
            return View(product_Table);
        }


        // GET: StockProduct/Create
        public ActionResult Create()
        {
            ViewBag.Branch_ID = new SelectList(db.Branch_Table, "ID", "Branch_Name");
            ViewBag.Brand_ID = new SelectList(db.Brand_Table, "ID", "Brand_Name");
            ViewBag.Category_ID = new SelectList(db.Category_Table, "ID", "Catagory_Name");
            return View();
        }

        // POST: StockProduct/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public ActionResult Create(Product_Table product_table)
        {

            db.SaveProductSP(product_table.Product_Code, product_table.Product_Name,product_table.Category_ID,product_table.Brand_ID,product_table.Branch_ID, product_table.Quantity, product_table.Sales_Price, product_table.Purchase_price, product_table.Entry_Date, product_table.Product_Description);

            ViewBag.success = "Data save successfully";
            return RedirectToAction("index");
        }

        // GET: Test_Table/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product_Table product_Table = db.Product_Table.Find(id);
            if (product_Table == null)
            {
                return HttpNotFound();
            }
            ViewBag.Branch_ID = new SelectList(db.Branch_Table, "ID", "Branch_Name", product_Table.Branch_ID);
            ViewBag.Brand_ID = new SelectList(db.Brand_Table, "ID", "Brand_Name", product_Table.Brand_ID);
            ViewBag.Category_ID = new SelectList(db.Category_Table, "ID", "Catagory_Name", product_Table.Category_ID);
            return View(product_Table);
        }

        // POST: StockProduct/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Product_Code,Product_Name,Quantity,Sales_Price,Purchase_price,Entry_Date,Product_Description")] Product_Table product_Table)
        {
            db.UpdateProductSP(product_Table.ID, product_Table.Product_Code, product_Table.Quantity);
            
           
            return RedirectToAction("Index");
        }

        // GET: StockProduct/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product_Table product_Table = db.Product_Table.Find(id);
            if (product_Table == null)
            {
                return HttpNotFound();
            }
            return View(product_Table);
        }

        // POST: StockProduct/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Product_Table product_Table = db.Product_Table.Find(id);
            db.Product_Table.Remove(product_Table);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}