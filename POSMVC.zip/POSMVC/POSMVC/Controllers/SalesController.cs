﻿
using POSMVC.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace POSMVC.Controllers
{
     [Authorize(Roles = "Sales")]
    public class SalesController : Controller
    {
        private POSDBEntities2 db = new POSDBEntities2();
        public ActionResult Index(string orderProduct)
        {
            ViewBag.listProduct = db.Product_Table.ToList();


            return View();
        }

        private int isExisting(int? id)
        {
            List<Item> cart = (List<Item>)Session["cart"];
            for (int i = 0; i < cart.Count; i++)

                if (cart[i].Pr.ID == id)
                    return i;

            return -1;
        }



        public ActionResult OrderNow(string Order_ID)
        {
            List<Product_Table> pl = db.Product_Table.ToList();
            var productId = from product in pl where product.Product_Code == Order_ID select new { pid = product.ID, ProductCode = product.Product_Code };
            int id = 0;
            foreach (var list in productId)
            {
                if (list.ProductCode == Order_ID)
                {
                    id = list.pid;

                  
                }

                else
                {
                    return View("Cart");
                }
             
            }


            if (Session["cart"] == null)
            {
                List<Item> cart = new List<Item>();
                cart.Add(new Item(db.Product_Table.Find(id), 1));
                Session["cart"] = cart;

            }
            else
            {
                List<Item> cart = (List<Item>)Session["cart"];
                int index = isExisting(id);
                if (index == -1){
                 cart.Add(new Item(db.Product_Table.Find(id), 1));
                }
                else 
                    cart[index].Quantity++;
                Session["cart"] = cart;
            }
            return View("Cart");
          // return View("Index");    
        }

        public ActionResult SaveSales(Sales_Table sales_table)
        {
            
            foreach (Item item in (List<Item>)Session["cart"])
            {

                db.SaveSalesInfoSP(sales_table.Product_Code = item.Pr.Product_Code, sales_table.Quantity=item.Quantity, sales_table.Sales_Price=(item.Pr.Sales_Price*item.Quantity));
            }
            
            Session.Clear();
            return View("Index");

        }

        public ActionResult Pay()
        {

            return View();
        }

        public ActionResult payment(string pay_amount, string acc_no)
        {
           List<Customer_Table> cus = db.Customer_Table.ToList();

           var result = from customer in cus where (customer.ACC_NO == acc_no) select new { dis = customer.Discount };
            decimal d=1;
            foreach (var list in result)
            {
               
                  d = Convert.ToDecimal(list.dis);
  
              }

            ViewBag.dis = d;
            double pay_amount_ex;

            if (pay_amount == null)
            {
                pay_amount_ex = 0;
            }

            else
            {
                pay_amount_ex = Convert.ToDouble(pay_amount);
            }
      
            ViewBag.pay =Convert.ToDecimal(pay_amount_ex);

            return View("Cart");

        } 
        }
    }
