﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using POSMVC.Models;

namespace POSMVC.Controllers
{
    public class PurchaseController : Controller
    {
        private POSDBEntities2 db = new POSDBEntities2();

        // GET: Purchase
        public ActionResult Index()
        {
            var purchase_Table = db.Purchase_Table.Include(p => p.Brand_Table).Include(p => p.Category_Table);
            return View(purchase_Table.ToList());
        }

        // GET: Purchase/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Purchase_Table purchase_Table = db.Purchase_Table.Find(id);
            if (purchase_Table == null)
            {
                return HttpNotFound();
            }
            return View(purchase_Table);
        }

        // GET: Purchase/Create
        public ActionResult Create()
        {
            ViewBag.Brand = new SelectList(db.Brand_Table, "ID", "Brand_Name");
            ViewBag.Category = new SelectList(db.Category_Table, "ID", "Catagory_Name");
            return View();
        }

        // POST: Purchase/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Purchase_Table purchase_Table)
        {
            db.SavePurchaseProdSP(purchase_Table.Product_Code, purchase_Table.Product_Name, purchase_Table.Brand, purchase_Table.Category, purchase_Table.Quantity, purchase_Table.Purchasing_Price, purchase_Table.Description, purchase_Table.Date);
            return RedirectToAction("Index");
        }

        // GET: Purchase/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Purchase_Table purchase_Table = db.Purchase_Table.Find(id);
            if (purchase_Table == null)
            {
                return HttpNotFound();
            }
            ViewBag.Brand = new SelectList(db.Brand_Table, "ID", "Brand_Name", purchase_Table.Brand);
            ViewBag.Category = new SelectList(db.Category_Table, "ID", "Catagory_Name", purchase_Table.Category);
            return View(purchase_Table);
        }

        // POST: Purchase/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Product_Code,Product_Name,Brand,Category,Quantity,Purchasing_Price,Description,Date")] Purchase_Table purchase_Table)
        {
            if (ModelState.IsValid)
            {
                db.Entry(purchase_Table).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Brand = new SelectList(db.Brand_Table, "ID", "Brand_Name", purchase_Table.Brand);
            ViewBag.Category = new SelectList(db.Category_Table, "ID", "Catagory_Name", purchase_Table.Category);
            return View(purchase_Table);
        }

        // GET: Purchase/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Purchase_Table purchase_Table = db.Purchase_Table.Find(id);
            if (purchase_Table == null)
            {
                return HttpNotFound();
            }
            return View(purchase_Table);
        }

        // POST: Purchase/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Purchase_Table purchase_Table = db.Purchase_Table.Find(id);
            db.Purchase_Table.Remove(purchase_Table);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
