﻿using POSMVC.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace POSMVC.Controllers
{
    [Authorize(Roles = "Admin")]
    public class BrandController: Controller
    {
        private POSDBEntities2 db = new POSDBEntities2();
        // GET: Category
        public ActionResult Index()
        {
            return View(db.Brand_Table.ToList());
        }

        // GET: StockProduct/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Brand_Table brand_Table = db.Brand_Table.Find(id);
            if (brand_Table == null)
            {
                return HttpNotFound();
            }
            return View(brand_Table);
        }


        // GET: StockProduct/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StockProduct/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public ActionResult Create(Brand_Table brand_Table)
        {

            db.SaveBrandSP(brand_Table.Brand_Name);

            ViewBag.success = "Data save successfully";
            return RedirectToAction("index");
        }

        // GET: StockProduct/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Brand_Table brand_Table = db.Brand_Table.Find(id);
            if (brand_Table == null)
            {
                return HttpNotFound();
            }
            return View(brand_Table);
        }

        // POST: StockProduct/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Brand_Name")] Brand_Table brand_Table)
        {
            if (ModelState.IsValid)
            {
                db.Entry(brand_Table).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(brand_Table);
        }

        // GET: StockProduct/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Brand_Table brand_Table = db.Brand_Table.Find(id);
            if (brand_Table == null)
            {
                return HttpNotFound();
            }
            return View(brand_Table);
        }

        // POST: StockProduct/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Brand_Table brand_Table = db.Brand_Table.Find(id);
            db.Brand_Table.Remove(brand_Table);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}

